# NodeRestApi

This source code is part of Node.js tutorial [How to create REST API easily using Node.js, Express.js and MongoDB](https://www.djamware.com/post/58a91cdf80aca748640ce353/how-to-create-rest-api-easily-using-nodejs-expressjs-mongoosejs-and-mongodb)
